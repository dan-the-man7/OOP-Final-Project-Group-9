package finalprojectgrp9;

import java.util.ArrayList;

public class Supplier {
    
    private String supplierLocation;
    private double carbonRating;
    private String supplierName;
    private int supplierID;
    private ArrayList<Route> routes;


    // Paramterized constructor created for supplier objects with parameters of 
    public Supplier(String supplierName, String supplierLocation, double carbonRating) {

        this.supplierName = supplierName;
        this.supplierLocation = supplierLocation;
        this.routes = new ArrayList<>();
        this.carbonRating = carbonRating;
        this.supplierID = supplierID;

    }

    // Getters created for Supplier class

    public void setSupplierName (String supplierName) {
        this.supplierName = supplierName;
    }

    public void setLocation (String supplierLocation) {
        this.supplierLocation = supplierLocation;
    }

    public void setCarbonRating (double carbonRating) {
        this.carbonRating = carbonRating;
    }

    // Getters created for Supplier class
    
    public String getSupplierName() {
        return supplierName;
    }

    public String getSupplierLocation() {
        return supplierLocation;
    }

    public void addRoute(Route r) {
        this.routes.add(r);
    }
    
    public double getCarbonRating() {
        return carbonRating;
    }

    public int getSupplierID() {
        return supplierID;
    }

    public void setSupplierID(int supplierID) {
        this.supplierID = supplierID;
    }

    public double calculateTotalEmissions() {
        double total = 0.0;

        for (Route r : routes) {
            total += r.computeTotalEmissions();
        }

        return total;
    }

    // toString() method overriden to display supplier details.
    @Override

    public String toString() {
        return "Supplier Name: " + supplierName + ", Supplier Location: " + supplierLocation + ", Supplier Carbon Rating: " + carbonRating;
    }

    // Equals method overriden to check if two suppliers are equal based on their name and location.

    @Override

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        
        if (obj == null || this.getClass() != obj.getClass()) {
            return false;
        }

        Supplier other = (Supplier)obj;

        return this.supplierName.equals(other.supplierName) && this.supplierLocation.equals(other.supplierLocation);
    }

    // HashCode() Method Overriden
    @Override

    public int hashCode() {
        int hash = 7;

        hash = 31 * hash + (int)carbonRating;
        hash = 31 * hash + (supplierLocation == null ? 0 : supplierLocation.hashCode());
        hash = 31 * hash + (supplierName == null ? 0 : supplierName.hashCode());

        return hash;

    }
}   
