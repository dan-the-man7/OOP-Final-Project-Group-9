// package finalprojectgrp9;

// import java.awt.*;
// import java.awt.event.*;
// import javax.swing.*;

// public class SupplierGUI extends JFrame implements  ActionListener{
//     private JTextField nameField, ageField, idField;
//     private JTextArea outputArea;
//     private JButton addButton, clearButton;
//     private JComboBox<String> genderBox;

//     public SupplierGUI() {
//         setTitle("Supplier Info Form");
//         setSize(550, 300);
//         setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//         setLayout(new FlowLayout());

//         add(new JLabel("Name:"));
//         nameField = new JTextField(15);
//         add(nameField);

//         add(new JLabel("Age:"));
//         ageField = new JTextField(5);
//         add(ageField);

//         add(new JLabel("StudentID"));
//         idField = new JTextField(5);
//         add(idField);

//         addButton = new JButton("Add Student");
//         addButton.addActionListener(this); // Interface method
//         add(addButton);

//         add(new JLabel("Gender: "));
//         String[] genderOptions = {"Male", "Female", "Other"};
//         genderBox = new JComboBox<>(genderOptions);
//         add(genderBox);

//         clearButton = new JButton("Clear");
//         clearButton.addActionListener(this);
//         add(clearButton);
        
//         outputArea = new JTextArea(5, 40);
//         outputArea.setEditable(false);
//         add(new JScrollPane(outputArea));

//         setVisible(true);
//     }

//     // Event-handling method (from ActionListener interface)
//     @Override
//     public void actionPerformed(ActionEvent e) {
//         if (e.getSource() == addButton) {
//             String name = nameField.getText();
//             int age = Integer.parseInt(ageField.getText());
//             String id = idField.getText();
//             String gender = (String)genderBox.getSelectedItem();

//             // Create an object of Student
//             Student s = new Student(name, age, id, gender);
//             outputArea.append(s.getInfo() + "\n");

//             // Clear fields
//             nameField.setText("");
//             ageField.setText("");
//             idField.setText("");
//         }
    
//         else if (e.getSource() == clearButton) {
//             outputArea.setText("");
//         }
        
//     }

//     public static void main(String[] args) {
//         new StudentForm();
//     }
// }
//  }
