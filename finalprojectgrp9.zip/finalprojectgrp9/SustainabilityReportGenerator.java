package finalprojectgrp9;

public interface SustainabilityReportGenerator {

    void generateSupplierReport();

    void pickSustainableSupplier();

    void sortSuppliers();
}