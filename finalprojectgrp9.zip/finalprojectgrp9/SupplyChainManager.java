package finalprojectgrp9;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.TreeMap;

public class SupplyChainManager implements SustainabilityReportGenerator {
    private TreeMap<Integer, Supplier> suppliers;
    private String managerName;
    private int nextSupplierID;


    public SupplyChainManager() {
        this.suppliers = new TreeMap<>();
        this.managerName = managerName;
        this.nextSupplierID = 0;
    }


    public String getManagerName() {
        return managerName;
    }


    public void setManagerName(String managerName) {
        this.managerName = managerName;
    }

    
    public void addSupplier(Supplier s) {
        suppliers.put(nextSupplierID++, s);
    }

    public void removeSupplier(int sID) {
        suppliers.remove(sID);
    }

    // Implements abstract method from SustainabilityReportGenerator Interface to generate report on suppliers
    @Override
    public void generateSupplierReport() {

    };

    // Implements abstract method from SustainabilityReportGenerator Interface to pick most sustainable supplier
    @Override
    public void pickSustainableSupplier() {
        Supplier efficientSupplier = null;
        double lowestEmissions = Double.MAX_VALUE;

        for (Supplier s: suppliers.values()) {
            double currentEmission = s.calculateTotalEmissions();


            System.out.println("Supplier name: " + s.getSupplierName() + " | Total Emissions " + currentEmission + " kgC02e (kilograms of carbon dioxide equivalent)\n");

            if (currentEmission < lowestEmissions) {
                lowestEmissions = currentEmission;
                efficientSupplier = s;
            }
        }

        if (efficientSupplier != null) {
            System.out.println("Supplier with the Lowest Emissions Found");

            System.out.println("Supplier Name: " + efficientSupplier.getSupplierName() + " Total Emissions: " + lowestEmissions + " kgC02e (kilograms of carbon dioxide equivalent)\n");
        }
        
        else {
            System.out.println("There were no suppliers found");
        }

    }

    // Implements abstract method from SustainabilityReportGenerator Interface to pick most sustainable supplier
    @Override
    public void sortSuppliers() {

        ArrayList<Supplier> sortedList = new ArrayList<>(suppliers.values());

        Comparator carbonCompare = new Comparator<Supplier>() {

        @Override
        public int compare(Supplier i, Supplier j) {
            if (i.getCarbonRating() > j.getCarbonRating()) {
                return 1;
            }
            else
                return -1;
        }
        
     };

        sortedList.sort(carbonCompare);

        for(Supplier s : sortedList) {
            System.out.println(s);
        }
        
    }
    
    

    public static void main(String[] args) {

        ArrayList<String> productList = new ArrayList<>();

        productList.add("Metals");
        productList.add("Gold");

        SupplyChainManager scm = new SupplyChainManager();

        Supplier s1 = new Supplier("DPK LTD", "Berekuso",0.9);

        Supplier s2 = new Supplier("PKD LTD", "Accra",0.8);

        Supplier s3 = new Supplier("DBK LTD", "Accra",0.89);

        Route r1 = new Route(1, "Berekuso", "Pokuase", TransportMode.ROAD_TRUCK, 20, 5.5);

        Route r2 = new Route(6, "Ashale Botwe", "Spintex", TransportMode.ROAD_EVTRUCK, 15, 3.5);

        Route r3 = new Route(4, "East Legon", "North Legon", TransportMode.ROAD_TRUCK, 25, 2.5);

        scm.addSupplier(s1);

        scm.addSupplier(s2);

        scm.addSupplier(s3);

        s1.addRoute(r1);

        s2.addRoute(r2);

        s3.addRoute(r3);

        scm.sortSuppliers();

        scm.pickSustainableSupplier();

    }



    
    
}
